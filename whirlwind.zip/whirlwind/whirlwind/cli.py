import json
import os
import sys
import tempfile
import subprocess
import urllib.error
import urllib.request


# ==========================================================
# WHIRLWIND MODULE IMPORTS
# ==========================================================

try:
    # Used when starting with:
    # python -m whirlwind
    from .modules.recon.scanner import run_scanner

except ImportError:
    # Used if cli.py is run directly
    from modules.recon.scanner import run_scanner


# Login Audit is optional.
# Whirlwind will still run if the module is not installed yet.
try:
    from .modules.login_audit import run_login_audit

except ImportError:
    try:
        from modules.login_audit import run_login_audit

    except ImportError:
        run_login_audit = None


# ==========================================================
# VERSION / UPDATE SETTINGS
# ==========================================================

CURRENT_VERSION = "0.1.0"

# CHANGE THESE TO YOUR GITHUB INFORMATION
GITHUB_OWNER = "Kali-byte300"
GITHUB_REPO = "whirlwind"

GITHUB_API_VERSION = "2026-03-10"


# ==========================================================
# SETTINGS
# ==========================================================

SETTINGS_FILE = "whirlwind_settings.json"


COLORS = {
    "Default": "\033[0m",
    "Green": "\033[92m",
    "Blue": "\033[94m",
    "Cyan": "\033[96m",
    "Yellow": "\033[93m",
    "Purple": "\033[95m",
    "Red": "\033[91m",
    "White": "\033[97m",
}


DEFAULT_SETTINGS = {
    "color": "Default",
    "display_size": "Normal",
    "show_emojis": True,
}


# ==========================================================
# BASIC FUNCTIONS
# ==========================================================

def enable_windows_ansi():

    if os.name == "nt":
        os.system("")


def load_settings():

    if not os.path.exists(SETTINGS_FILE):

        return DEFAULT_SETTINGS.copy()

    try:

        with open(
            SETTINGS_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            saved = json.load(file)

        settings_data = DEFAULT_SETTINGS.copy()

        settings_data.update(saved)

        return settings_data

    except (
        json.JSONDecodeError,
        OSError
    ):

        return DEFAULT_SETTINGS.copy()


settings = load_settings()


def save_settings():

    try:

        with open(
            SETTINGS_FILE,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                settings,
                file,
                indent=4
            )

    except OSError:

        pass


def color_code():

    return COLORS.get(
        settings["color"],
        COLORS["Default"]
    )


def reset_color():

    print(
        "\033[0m",
        end=""
    )


def clear_screen():

    os.system(
        "cls"
        if os.name == "nt"
        else "clear"
    )


def pause():

    input(
        "\nPress Enter to continue..."
    )


def icon(
    emoji,
    text
):

    if settings["show_emojis"]:

        return f"{emoji} {text}"

    return text


# ==========================================================
# BANNER
# ==========================================================

def show_banner():

    print(
        color_code(),
        end=""
    )

    if settings["display_size"] == "Large":

        print()

        print(
            "╔══════════════════════════════════════════════╗"
        )

        print(
            "║                                              ║"
        )

        print(
            "║           W H I R L W I N D                  ║"
        )

        print(
            "║                                              ║"
        )

        print(
            "║         Lightweight Security Suite           ║"
        )

        print(
            "║                                              ║"
        )

        print(
            "╚══════════════════════════════════════════════╝"
        )

        print()

    else:

        print(
            "╔══════════════════════════════════╗"
        )

        print(
            "║          W H I R L W I N D       ║"
        )

        print(
            "║     Lightweight Security Suite   ║"
        )

        print(
            "╚══════════════════════════════════╝"
        )

        print()


# ==========================================================
# OTHER TOOLS
# ==========================================================

def other_tools_menu():

    while True:

        clear_screen()

        show_banner()

        print(
            "OTHER TOOLS"
        )

        print(
            "------------------------------"
        )

        print()

        print(
            "[1] DNS Tools"
        )

        print(
            "[2] Web Security Tools"
        )

        print(
            "[3] Login Security Audit"
        )

        print(
            "[4] OSINT Tools"
        )

        print(
            "[5] Packet Tools"
        )

        print(
            "[6] Back"
        )

        print()

        choice = input(
            "Other Tools > "
        ).strip()


        if choice == "3":

            if run_login_audit is None:

                print()

                print(
                    icon(
                        "🔧",
                        "Login Security Audit module "
                        "was not found."
                    )
                )

                pause()

            else:

                clear_screen()

                run_login_audit()


        elif choice == "6":

            break


        elif choice in [
            "1",
            "2",
            "4",
            "5"
        ]:

            print()

            print(
                icon(
                    "🔧",
                    "This tool is coming soon."
                )
            )

            pause()


        else:

            print()

            print(
                "Invalid option."
            )

            pause()


# ==========================================================
# COLOR SETTINGS
# ==========================================================

def choose_color():

    while True:

        clear_screen()

        show_banner()

        print(
            "TEXT COLOR"
        )

        print(
            "------------------------------"
        )

        print()

        print(
            "[1] Cyan"
        )

        print(
            "[2] Green"
        )

        print(
            "[3] Blue"
        )

        print(
            "[4] Yellow"
        )

        print(
            "[5] Purple"
        )

        print(
            "[6] Red"
        )

        print(
            "[7] White"
        )

        print(
            "[8] Default"
        )

        print(
            "[9] Back"
        )

        print()


        choice = input(
            "Color > "
        ).strip()


        options = {
            "1": "Cyan",
            "2": "Green",
            "3": "Blue",
            "4": "Yellow",
            "5": "Purple",
            "6": "Red",
            "7": "White",
            "8": "Default",
        }


        if choice in options:

            settings["color"] = options[
                choice
            ]

            save_settings()

            print()

            print(
                f"Text color changed to "
                f"{settings['color']}."
            )

            pause()


        elif choice == "9":

            break


        else:

            print()

            print(
                "Invalid option."
            )

            pause()


# ==========================================================
# DISPLAY SIZE
# ==========================================================

def choose_display_size():

    while True:

        clear_screen()

        show_banner()

        print(
            "DISPLAY SIZE"
        )

        print(
            "------------------------------"
        )

        print()

        print(
            "[1] Normal"
        )

        print(
            "[2] Large"
        )

        print(
            "[3] Back"
        )

        print()


        choice = input(
            "Display Size > "
        ).strip()


        if choice == "1":

            settings["display_size"] = "Normal"

            save_settings()

            print()

            print(
                "Display size changed to Normal."
            )

            pause()


        elif choice == "2":

            settings["display_size"] = "Large"

            save_settings()

            print()

            print(
                "Display size changed to Large."
            )

            pause()


        elif choice == "3":

            break


        else:

            print()

            print(
                "Invalid option."
            )

            pause()


# ==========================================================
# EMOJI SETTINGS
# ==========================================================

def emoji_settings():

    while True:

        clear_screen()

        show_banner()


        current = (
            "ON"
            if settings["show_emojis"]
            else "OFF"
        )


        print(
            "EMOJIS"
        )

        print(
            "------------------------------"
        )

        print()

        print(
            f"Current: {current}"
        )

        print()

        print(
            "[1] Turn ON"
        )

        print(
            "[2] Turn OFF"
        )

        print(
            "[3] Back"
        )

        print()


        choice = input(
            "Emojis > "
        ).strip()


        if choice == "1":

            settings["show_emojis"] = True

            save_settings()

            print()

            print(
                "Emojis turned ON."
            )

            pause()


        elif choice == "2":

            settings["show_emojis"] = False

            save_settings()

            print()

            print(
                "Emojis turned OFF."
            )

            pause()


        elif choice == "3":

            break


        else:

            print()

            print(
                "Invalid option."
            )

            pause()


# ==========================================================
# UPDATE SYSTEM
# ==========================================================

def version_tuple(version):

    version = (
        version
        .strip()
        .lower()
        .lstrip("v")
    )


    parts = []


    for piece in version.split("."):

        number = ""


        for character in piece:

            if character.isdigit():

                number += character

            else:

                break


        if number:

            parts.append(
                int(number)
            )

        else:

            parts.append(0)


    while len(parts) < 3:

        parts.append(0)


    return tuple(
        parts[:3]
    )


def get_latest_release():

    if GITHUB_OWNER == "YOUR_GITHUB_USERNAME":

        raise RuntimeError(
            "You need to set your GitHub username "
            "in cli.py first."
        )


    url = (
        "https://api.github.com/repos/"
        f"{GITHUB_OWNER}/"
        f"{GITHUB_REPO}/"
        "releases/latest"
    )


    request = urllib.request.Request(

        url,

        headers={
            "Accept":
                "application/vnd.github+json",

            "X-GitHub-Api-Version":
                GITHUB_API_VERSION,

            "User-Agent":
                "Whirlwind-Updater",
        }
    )


    with urllib.request.urlopen(
        request,
        timeout=10
    ) as response:

        data = response.read().decode(
            "utf-8"
        )


        return json.loads(
            data
        )


def find_windows_exe(
    release
):

    assets = release.get(
        "assets",
        []
    )


    for asset in assets:

        filename = asset.get(
            "name",
            ""
        ).lower()


        if filename.endswith(
            ".exe"
        ):

            return asset


    return None


def download_update(
    download_url,
    destination
):

    request = urllib.request.Request(

        download_url,

        headers={
            "User-Agent":
                "Whirlwind-Updater"
        }
    )


    with urllib.request.urlopen(
        request,
        timeout=60
    ) as response:


        with open(
            destination,
            "wb"
        ) as file:


            while True:

                chunk = response.read(
                    1024 * 1024
                )


                if not chunk:

                    break


                file.write(
                    chunk
                )


def install_update(
    downloaded_exe
):


    if os.name != "nt":

        print()

        print(
            "Automatic updates currently "
            "support Windows."
        )

        print()

        print(
            "Downloaded file:"
        )

        print(
            downloaded_exe
        )

        pause()

        return


    if not getattr(
        sys,
        "frozen",
        False
    ):

        print()

        print(
            "✅ Update downloaded."
        )

        print()

        print(
            "Automatic replacement works "
            "after Whirlwind is packaged "
            "as an EXE."
        )

        print()

        print(
            "Downloaded file:"
        )

        print(
            downloaded_exe
        )

        pause()

        return


    current_exe = os.path.abspath(
        sys.executable
    )


    current_folder = os.path.dirname(
        current_exe
    )


    updater_file = os.path.join(
        tempfile.gettempdir(),
        "whirlwind_updater.bat"
    )


    batch_script = (

        "@echo off\n"

        "echo Updating Whirlwind...\n"

        "timeout /t 2 /nobreak >nul\n"

        f'copy /y '
        f'"{downloaded_exe}" '
        f'"{current_exe}" '
        f'>nul\n'

        f'start "" '
        f'"{current_exe}"\n'

        'del "%~f0"\n'
    )


    try:

        with open(
            updater_file,
            "w",
            encoding="utf-8"
        ) as file:

            file.write(
                batch_script
            )


    except OSError:

        print()

        print(
            "⛔ Could not create "
            "the update installer."
        )

        pause()

        return


    subprocess.Popen(

        [
            "cmd",
            "/c",
            updater_file
        ],

        cwd=current_folder,

        creationflags=getattr(
            subprocess,
            "CREATE_NO_WINDOW",
            0
        )
    )


    print()

    print(
        "✅ Update downloaded."
    )

    print()

    print(
        "Whirlwind will close, "
        "install the update, "
        "and restart."
    )


    reset_color()


    raise SystemExit


def check_for_updates():

    clear_screen()

    show_banner()


    print(
        "CHECK FOR UPDATES"
    )

    print(
        "------------------------------"
    )

    print()

    print(
        f"Current version : "
        f"{CURRENT_VERSION}"
    )

    print()

    print(
        "Checking for updates..."
    )


    try:

        release = get_latest_release()


    except RuntimeError as error:

        print()

        print(
            f"⛔ {error}"
        )

        pause()

        return


    except urllib.error.HTTPError as error:

        print()


        if error.code == 404:

            print(
                "⛔ Whirlwind update server "
                "was not found."
            )

            print()

            print(
                "Check your GitHub username "
                "and repository name."
            )


        else:

            print(
                f"⛔ GitHub HTTP error: "
                f"{error.code}"
            )


        pause()

        return


    except urllib.error.URLError:

        print()

        print(
            "⛔ Could not connect "
            "to GitHub."
        )

        print()

        print(
            "Check your internet connection."
        )

        pause()

        return


    except TimeoutError:

        print()

        print(
            "⛔ Update check timed out."
        )

        pause()

        return


    except json.JSONDecodeError:

        print()

        print(
            "⛔ Invalid update information "
            "was received."
        )

        pause()

        return


    latest_version = release.get(
        "tag_name",
        ""
    ).strip()


    if not latest_version:

        print()

        print(
            "⛔ Could not determine "
            "the latest version."
        )

        pause()

        return


    print()

    print(
        f"Latest version  : "
        f"{latest_version}"
    )


    if (
        version_tuple(
            latest_version
        )
        <=
        version_tuple(
            CURRENT_VERSION
        )
    ):

        print()

        print(
            icon(
                "✅",
                "Whirlwind is already up to date."
            )
        )

        pause()

        return


    print()

    print(
        icon(
            "🌪️",
            "NEW WHIRLWIND UPDATE AVAILABLE!"
        )
    )

    print(
        "------------------------------"
    )

    print()


    release_name = release.get(
        "name",
        latest_version
    )


    print(
        f"Release : {release_name}"
    )

    print(
        f"Version : {latest_version}"
    )


    release_notes = release.get(
        "body",
        ""
    ).strip()


    if release_notes:

        print()

        print(
            "What's new:"
        )

        print()

        print(
            release_notes[:1500]
        )


    exe_asset = find_windows_exe(
        release
    )


    if exe_asset is None:

        print()

        print(
            "⛔ No Windows EXE was found "
            "in this release."
        )

        print()

        print(
            "Upload Whirlwind.exe as "
            "a GitHub Release asset."
        )

        pause()

        return


    print()

    print(
        "[1] Download and Install"
    )

    print(
        "[2] Back"
    )

    print()


    choice = input(
        "Update > "
    ).strip()


    if choice != "1":

        return


    download_url = exe_asset.get(
        "browser_download_url"
    )


    filename = exe_asset.get(
        "name",
        "Whirlwind.exe"
    )


    if not download_url:

        print()

        print(
            "⛔ Update download URL "
            "was missing."
        )

        pause()

        return


    destination = os.path.join(
        tempfile.gettempdir(),
        "Whirlwind_Update.exe"
    )


    print()

    print(
        f"Downloading {filename}..."
    )


    try:

        download_update(
            download_url,
            destination
        )


    except (
        urllib.error.URLError,
        TimeoutError,
        OSError
    ):

        print()

        print(
            "⛔ Update download failed."
        )

        pause()

        return


    print()

    print(
        "✅ Download complete."
    )


    install_update(
        destination
    )


# ==========================================================
# RESET SETTINGS
# ==========================================================

def reset_settings():

    global settings


    print()


    answer = input(
        "Reset all settings to default? "
        "(yes/no): "
    ).strip().lower()


    if answer == "yes":

        settings = (
            DEFAULT_SETTINGS.copy()
        )

        save_settings()

        print()

        print(
            "Settings reset."
        )


    else:

        print()

        print(
            "Cancelled."
        )


    pause()


# ==========================================================
# SETTINGS MENU
# ==========================================================

def settings_menu():

    while True:

        clear_screen()

        show_banner()


        emoji_status = (
            "ON"
            if settings["show_emojis"]
            else "OFF"
        )


        print(
            "SETTINGS"
        )

        print(
            "------------------------------"
        )

        print()


        print(
            f"[1] Text Color       "
            f"({settings['color']})"
        )


        print(
            f"[2] Display Size     "
            f"({settings['display_size']})"
        )


        print(
            f"[3] Emojis           "
            f"({emoji_status})"
        )


        print(
            "[4] Check for Updates"
        )


        print(
            "[5] Reset Settings"
        )


        print(
            "[6] Back"
        )


        print()


        choice = input(
            "Settings > "
        ).strip()


        if choice == "1":

            choose_color()


        elif choice == "2":

            choose_display_size()


        elif choice == "3":

            emoji_settings()


        elif choice == "4":

            check_for_updates()


        elif choice == "5":

            reset_settings()


        elif choice == "6":

            break


        else:

            print()

            print(
                "Invalid option."
            )

            pause()


# ==========================================================
# ABOUT
# ==========================================================

def about_menu():

    clear_screen()

    show_banner()


    print(
        "ABOUT WHIRLWIND"
    )

    print(
        "------------------------------"
    )

    print()


    print(
        "Whirlwind is a lightweight "
        "modular security toolkit."
    )

    print()


    print(
        "Main tool:"
    )

    print(
        icon(
            "🌪️",
            "Whirlwind Network Scanner"
        )
    )

    print()


    print(
        "Other tools:"
    )

    print(
        "• Login Security Audit"
    )

    print(
        "• More coming later"
    )

    print()


    print(
        f"Version: {CURRENT_VERSION}"
    )

    print()


    pause()


# ==========================================================
# MAIN MENU
# ==========================================================

def main():

    enable_windows_ansi()


    while True:

        clear_screen()

        show_banner()


        print(
            "[1] Whirlwind Network Scanner"
        )

        print(
            "[2] Other Tools"
        )

        print(
            "[3] Settings"
        )

        print(
            "[4] About"
        )

        print(
            "[5] Exit"
        )

        print()


        choice = input(
            "Whirlwind > "
        ).strip()


        if choice == "1":

            clear_screen()

            show_banner()

            run_scanner()


        elif choice == "2":

            other_tools_menu()


        elif choice == "3":

            settings_menu()


        elif choice == "4":

            about_menu()


        elif choice == "5":

            print()

            print(
                icon(
                    "🌪️",
                    "Whirlwind shutting down. WHOOSH!"
                )
            )

            reset_color()

            break


        else:

            print()

            print(
                "Invalid option."
            )

            pause()


# ==========================================================
# START WHIRLWIND
# ==========================================================

if __name__ == "__main__":

    main()