import socket
import ipaddress
import time
from concurrent.futures import ThreadPoolExecutor, as_completed


SERVICE_NAMES = {
    20: "FTP-DATA",
    21: "FTP",
    22: "SSH",
    23: "TELNET",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    123: "NTP",
    135: "MSRPC",
    139: "NETBIOS",
    143: "IMAP",
    389: "LDAP",
    443: "HTTPS",
    445: "SMB",
    587: "SMTP-SUBMISSION",
    636: "LDAPS",
    1433: "MSSQL",
    3306: "MYSQL",
    3389: "RDP",
    5432: "POSTGRESQL",
    5900: "VNC",
    6379: "REDIS",
    8000: "HTTP-ALT",
    8080: "HTTP-ALT",
    8443: "HTTPS-ALT",
}


SCAN_PRESETS = {
    "1": (
        "Quick Scan",
        [22, 80, 443, 445, 3389]
    ),
    "2": (
        "Common Ports",
        [
            20, 21, 22, 23, 25, 53, 80, 110, 123,
            135, 139, 143, 389, 443, 445, 587, 636,
            1433, 3306, 3389, 5432, 5900, 6379,
            8000, 8080, 8443
        ]
    ),
    "3": (
        "Web Scan",
        [80, 443, 8000, 8080, 8443]
    ),
    "4": (
        "Windows Scan",
        [135, 139, 445, 3389]
    ),
}


DISCOVERY_PORTS = [22, 80, 443, 445, 3389]


def get_my_ip():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]

    except OSError:
        return "Unknown"

    finally:
        sock.close()


def get_hostname(ip):
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
        return hostname

    except (socket.herror, socket.gaierror, OSError):
        return "unknown"


def resolve_target(target):
    """
    Accept an IPv4 address or hostname.
    Returns the resolved IPv4 address.
    """

    target = target.strip()

    try:
        ip = ipaddress.ip_address(target)

        if ip.version != 4:
            return None

        return str(ip)

    except ValueError:
        pass

    try:
        return socket.gethostbyname(target)

    except socket.gaierror:
        return None


def parse_ports(text):
    ports = set()

    for piece in text.split(","):
        piece = piece.strip()

        if not piece:
            continue

        if "-" in piece:
            start_text, end_text = piece.split("-", 1)

            start = int(start_text)
            end = int(end_text)

            if start < 1 or end > 65535 or start > end:
                raise ValueError

            ports.update(range(start, end + 1))

        else:
            port = int(piece)

            if port < 1 or port > 65535:
                raise ValueError

            ports.add(port)

    if not ports:
        raise ValueError

    return sorted(ports)


def scan_port(target, port, timeout=0.35):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)

    try:
        result = sock.connect_ex((target, port))
        return result == 0

    except OSError:
        return False

    finally:
        sock.close()


def service_name(port):
    return SERVICE_NAMES.get(port, "unknown")


def measure_latency(target):
    start = time.perf_counter()

    for port in DISCOVERY_PORTS:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.4)

        try:
            sock.connect_ex((target, port))

            elapsed = (time.perf_counter() - start) * 1000

            return round(elapsed, 1)

        except OSError:
            pass

        finally:
            sock.close()

    return None


def ask_target():
    print()
    print("Enter an IP address or hostname.")
    print()
    print("Examples:")
    print("192.168.1.25")
    print("10.0.0.10")
    print("localhost")
    print("example.com")
    print()

    target_text = input("Target: ").strip()

    resolved_ip = resolve_target(target_text)

    if not resolved_ip:
        print()
        print("⛔ Whirlwind could not resolve that target.")
        return None, None

    print()
    print(f"Target      : {target_text}")
    print(f"Resolved IP : {resolved_ip}")
    print()
    print("⚠️ Only scan systems you own or have permission to test.")

    permission = input(
        "Do you have authorization to scan this target? (yes/no): "
    ).strip().lower()

    if permission != "yes":
        print()
        print("Scan cancelled.")
        return None, None

    return target_text, resolved_ip


def run_port_scan(target_text, target_ip, ports, scan_name):
    hostname = get_hostname(target_ip)

    print()
    print("==============================================")
    print(f"SCAN TYPE : {scan_name}")
    print(f"TARGET    : {target_text}")
    print(f"IP        : {target_ip}")
    print(f"HOSTNAME  : {hostname}")
    print(f"PORTS     : {len(ports)}")
    print("==============================================")
    print()

    started = time.perf_counter()

    open_ports = []

    print(f"{'PORT':<10}{'STATE':<12}{'SERVICE'}")
    print("-" * 38)

    for port in ports:
        if scan_port(target_ip, port):
            service = service_name(port)

            print(f"{port:<10}{'OPEN':<12}{service}")

            open_ports.append(port)

    elapsed = time.perf_counter() - started
    latency = measure_latency(target_ip)

    print()
    print("-" * 38)
    print("SCAN SUMMARY")
    print("-" * 38)
    print(f"Target         : {target_text}")
    print(f"Resolved IP    : {target_ip}")
    print(f"Hostname       : {hostname}")
    print(f"Ports checked  : {len(ports)}")
    print(f"Open ports     : {len(open_ports)}")
    print(f"Scan time      : {elapsed:.2f} seconds")

    if latency is not None:
        print(f"Response time  : ~{latency} ms")

    if open_ports:
        print()
        print("Open ports:")
        print(", ".join(str(port) for port in open_ports))

    else:
        print()
        print("No open ports were found in this scan.")

    print()
    print("🌪️ Scan complete.")


def preset_scan(choice):
    target_text, target_ip = ask_target()

    if not target_ip:
        return

    scan_name, ports = SCAN_PRESETS[choice]

    run_port_scan(
        target_text=target_text,
        target_ip=target_ip,
        ports=ports,
        scan_name=scan_name
    )


def custom_scan():
    target_text, target_ip = ask_target()

    if not target_ip:
        return

    print()
    print("Custom port examples:")
    print("80")
    print("22,80,443")
    print("1-100")
    print("22,80,443,8000-8010")
    print()

    text = input("Ports to scan: ").strip()

    try:
        ports = parse_ports(text)

    except ValueError:
        print()
        print("⛔ Invalid port format.")
        return

    run_port_scan(
        target_text=target_text,
        target_ip=target_ip,
        ports=ports,
        scan_name="Custom Port Scan"
    )


def host_looks_online(ip):
    for port in DISCOVERY_PORTS:
        if scan_port(str(ip), port, timeout=0.2):
            return True

    return False


def find_devices():
    print()
    print("🌪️ FIND DEVICES ON MY NETWORK")
    print("--------------------------------")
    print()

    my_ip = get_my_ip()

    print(f"💻 Your IP address: {my_ip}")
    print()
    print("This feature is for local/private network discovery.")
    print()
    print("Example:")
    print("192.168.1.0/24")
    print()

    network_text = input("Network to scan: ").strip()

    try:
        network = ipaddress.ip_network(network_text, strict=False)

    except ValueError:
        print()
        print("⛔ Invalid network.")
        return

    if not network.is_private:
        print()
        print("⛔ Network discovery is limited to private networks.")
        return

    if network.num_addresses > 256:
        print()
        print("⛔ Network discovery is limited to /24 or smaller.")
        return

    permission = input(
        f"Do you have permission to scan {network_text}? (yes/no): "
    ).strip().lower()

    if permission != "yes":
        print()
        print("Discovery cancelled.")
        return

    hosts = list(network.hosts())

    print()
    print(f"🔍 Checking {len(hosts)} addresses...")
    print()

    started = time.perf_counter()

    online_hosts = []

    with ThreadPoolExecutor(max_workers=32) as executor:
        futures = {
            executor.submit(host_looks_online, ip): ip
            for ip in hosts
        }

        for future in as_completed(futures):
            ip = futures[future]

            try:
                if future.result():
                    online_hosts.append(str(ip))

            except Exception:
                pass

    online_hosts.sort(
        key=lambda address: ipaddress.ip_address(address)
    )

    elapsed = time.perf_counter() - started

    print(f"{'IP ADDRESS':<18}{'HOSTNAME':<28}{'STATUS'}")
    print("-" * 68)

    for ip in online_hosts:
        hostname = get_hostname(ip)

        if ip == my_ip:
            status = "THIS COMPUTER ✅"
        else:
            status = "ONLINE ✅"

        print(f"{ip:<18}{hostname:<28}{status}")

    print()
    print("-" * 68)
    print(f"Devices found : {len(online_hosts)}")
    print(f"Scan time     : {elapsed:.2f} seconds")

    if not online_hosts:
        print()
        print("No responding devices were found.")

    print()


def run_scanner():
    while True:
        print()
        print("╔══════════════════════════════════════╗")
        print("║     WHIRLWIND NETWORK SCANNER        ║")
        print("╚══════════════════════════════════════╝")
        print()
        print("[1] Quick Scan")
        print("[2] Common Ports")
        print("[3] Web Scan")
        print("[4] Windows Scan")
        print("[5] Custom Port Scan")
        print("[6] Find Devices on My Network")
        print("[7] Back")
        print()

        choice = input("Scanner > ").strip()

        if choice in ["1", "2", "3", "4"]:
            preset_scan(choice)
            input("\nPress Enter to continue...")

        elif choice == "5":
            custom_scan()
            input("\nPress Enter to continue...")

        elif choice == "6":
            find_devices()
            input("\nPress Enter to continue...")

        elif choice == "7":
            break

        else:
            print()
            print("⛔ Invalid option.")
            input("\nPress Enter to continue...")