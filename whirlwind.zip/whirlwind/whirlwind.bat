@echo off
cd /d "%~dp0"
title Whirlwind Security Suite

echo Starting Whirlwind...
python -m whirlwind

echo.
pause